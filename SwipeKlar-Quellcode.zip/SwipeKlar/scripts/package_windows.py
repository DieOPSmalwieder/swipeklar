"""Create source and Windows starter ZIPs using only Python's standard library."""
from io import BytesIO
from pathlib import Path
import sys
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
output = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root.parent / "library-files"
output.mkdir(parents=True, exist_ok=True)
excluded = {".git", ".build", "__pycache__", ".swiftpm", "DerivedData", "xcuserdata", "dist"}

source_path = output / "SwipeKlar-Quellcode.zip"
with ZipFile(source_path, "w", ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if path.is_file() and not excluded.intersection(relative.parts) and path.suffix != ".zip":
            archive.write(path, Path("SwipeKlar") / relative)

starter_path = output / "SwipeKlar-Windows.zip"
with ZipFile(starter_path, "w", ZIP_DEFLATED) as archive:
    archive.write(source_path, source_path.name)
    archive.write(root / "windows/build-iphone.yml", "build-iphone.yml")
    archive.write(root / "WINDOWS-ANLEITUNG.md", "WINDOWS-ANLEITUNG.md")

with ZipFile(starter_path) as starter:
    assert starter.testzip() is None
    assert set(starter.namelist()) == {"SwipeKlar-Quellcode.zip", "build-iphone.yml", "WINDOWS-ANLEITUNG.md"}
    assert starter.read("build-iphone.yml") == (root / "windows/build-iphone.yml").read_bytes()
    with ZipFile(BytesIO(starter.read("SwipeKlar-Quellcode.zip"))) as source:
        assert source.testzip() is None
        for required in ["SwipeKlar.xcodeproj/project.pbxproj", "scripts/build_ipa.sh", "Package.swift", "Tests/PhotoSelectionTests.swift"]:
            assert "SwipeKlar/" + required in source.namelist(), f"Missing source input: {required}"
        assert not any(name.endswith(".ipa") for name in source.namelist())

print(f"Source package: {source_path} ({source_path.stat().st_size:,} bytes)")
print(f"Windows starter: {starter_path} ({starter_path.stat().st_size:,} bytes); both archives verified")
