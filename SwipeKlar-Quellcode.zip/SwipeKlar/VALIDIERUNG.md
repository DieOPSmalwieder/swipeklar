# Prüfergebnisse

Prüfung am 13. Oktober 2026 in einer Linux-Umgebung.

- **7 Swift-Tests bestanden, 0 Fehler.** Die originale Auswahllogik und der Entscheidungsablauf wurden mit Swift 6.0.3 im Swift-Package kompiliert und als XCTest-Tests ausgeführt. Abgedeckt sind Jahrestage, 30-Tage-Grenze, zukünftige/undatierte Fotos, Zeitzonen, Schalttage, zufällige Auswahl, bereits abgeschlossene Fotos, Rückgängig und leere Runden.
- **Swift-Syntax geprüft:** alle App-Quelldateien vom Swift-Compiler im Parse-Modus akzeptiert; zusätzlich alle sieben Swift-Dateien mit der Swift-Grammatik von Tree-sitter geprüft. Die App verwendet Swift-5-Sprachmodus und setzt iOS 17 voraus.
- **Xcode-Projekt strukturell geprüft:** OpenStep-Projektdatei eingelesen; alle Objektverweise, Quelldateien und Ressourcen überprüft.
- **Gemeinsames Xcode-Scheme, Datenschutz-Manifest und App-Icon geprüft:** XML/Property-List/JSON lesbar; Icon 1024 × 1024 Pixel ohne Transparenz.

**Noch auf einem Mac bzw. iPhone erforderlich:** vollständiger iOS-Build mit SwiftUI/PhotoKit, Signierung, Bildschirmdarstellung, Berechtigungsdialoge und tatsächliches Löschen bzw. Abbrechen des Löschens. Linux bietet kein iOS-SDK; ein Syntaxcheck ersetzt keinen iOS-Build. Die Befehle und Geräteprüfungen stehen in `README.md`.

## Ergänzung für den Windows-Weg

Für die Installation vom Windows-PC gibt es nun eine vorbereitete GitHub-Actions-Anweisung und ein IPA-Buildskript. Der Workflow startet ausschließlich manuell, führt die vorhandenen Swift-Tests auf einem GitHub-Mac aus, baut für ein echtes iPhone ohne Signatur und stellt die IPA zum anschließenden Signieren in Sideloadly bereit. Es werden keine Apple-Zugangsdaten im Build benötigt.

Lokal geprüft: YAML-Struktur der Build-Anweisung, Bash-Syntax des Buildskripts, seine verständliche Ablehnung eines direkten Builds unter Linux und die ZIP-Struktur des Windows-Pakets einschließlich der enthaltenen Quelldateien. Die Quellen des iPhone-Programms und seiner Logiktests wurden bei dieser Ergänzung nicht verändert.

**Noch nicht ausgeführt:** der GitHub-Actions-Lauf und ein vollständiger iOS-Build, die Erzeugung einer echten IPA und die Sideloadly-Installation unter Windows. Das Windows-Paket enthält deshalb noch keine fertige IPA. Diese wird nach einem erfolgreichen Workflow-Lauf in deinem GitHub-Projekt verfügbar. Die Schrittfolge steht in `WINDOWS-ANLEITUNG.md`.
