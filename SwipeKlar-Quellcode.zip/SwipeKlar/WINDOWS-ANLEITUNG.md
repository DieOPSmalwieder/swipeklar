# SwipeKlar vom Windows-PC aufs iPhone bringen

Du brauchst einen Windows-PC (empfohlen Windows 10/11), ein USB-Datenkabel, ein iPhone mit **iOS 17 oder neuer**, eine kostenlose Apple-ID und ein kostenloses GitHub-Konto. Auf dem PC brauchst du kein Xcode und keine Programmierwerkzeuge.

GitHub baut die App auf einem bereitgestellten Mac. Sideloadly signiert sie anschließend mit deiner Apple-ID und installiert sie auf deinem iPhone. Ein kostenpflichtiges Apple-Entwicklerkonto ist dafür nicht erforderlich.

## 1. Das Windows-Paket entpacken

Lade `SwipeKlar-Windows.zip` herunter. Rechtsklick auf die Datei → **Alle extrahieren**. Im entpackten Ordner findest du:

- **SwipeKlar-Quellcode.zip** – diese Datei später unverändert auf GitHub hochladen.
- **build-iphone.yml** – die fertige Build-Anweisung für GitHub; mit dem Windows-Editor öffnen.
- **WINDOWS-ANLEITUNG.md** – diese Anleitung.

Die Quellcode-ZIP enthält noch keine installierbare App. Erst Schritt 4 erstellt `SwipeKlar.ipa`.

## 2. GitHub-Projekt erstellen und Quellcode hochladen

1. Auf <https://github.com> ein kostenloses Konto anlegen bzw. anmelden.
2. Über **+ → New repository** ein Projekt namens `swipeklar` erstellen.
3. **Public** auswählen und die Option **Add a README file** aktivieren, dann **Create repository**. Standard-GitHub-Buildrechner sind für öffentliche Projekte kostenlos. Der Quellcode und die Builddateien sind dann öffentlich; deine Fotos werden nicht hochgeladen.
4. Im neuen Projekt unter **Code → Add file → Upload files** die Datei **SwipeKlar-Quellcode.zip** hochladen. Die Datei bleibt gepackt. **Commit changes** anklicken und auf dem Hauptbranch (`main`) speichern.

## 3. Build-Anweisung einfügen

1. Im GitHub-Projekt unter **Code → Add file → Create new file** eine neue Datei anlegen.
2. Als vollständigen Dateinamen eingeben: **`.github/workflows/build-iphone.yml`**. Die Schrägstriche legen automatisch die nötigen Ordner an.
3. Die Datei **build-iphone.yml** aus unserem Windows-Paket mit dem Windows-Editor öffnen. Mit **Strg+A**, dann **Strg+C** den kompletten Inhalt kopieren und mit **Strg+V** in GitHubs großen Editor einfügen.
4. **Commit changes** anklicken und direkt auf `main` speichern. Die Datei muss auf dem Hauptbranch liegen, damit der manuelle Start erscheint.

Für den Build sind keine Apple-ID, kein Apple-Passwort, keine Apple-Zertifikate und keine GitHub-Secrets nötig. Die Apple-Anmeldung erfolgt erst später lokal in Sideloadly.

## 4. App bauen und herunterladen

1. Oben im GitHub-Projekt **Actions** öffnen.
2. Falls GitHub danach fragt, die Workflows für dein eigenes Projekt aktivieren.
3. Links **SwipeKlar iPhone bauen** auswählen.
4. **Run workflow** anklicken, `main` auswählen und mit **Run workflow** starten.
5. Den neuen Lauf öffnen und warten, bis ein grüner Haken erscheint. Das kann einige Minuten dauern.
6. In der Übersicht des abgeschlossenen Laufs nach unten zu **Artifacts** scrollen. **SwipeKlar-iPhone** herunterladen. Dafür musst du bei GitHub angemeldet sein.
7. Das heruntergeladene ZIP entpacken. Darin liegt **SwipeKlar.ipa**. Die `.ipa` selbst bleibt gepackt und wird in Sideloadly geladen.

Bei einem roten Kreuz den fehlgeschlagenen Schritt öffnen und die Fehlermeldung kopieren. Falls vorhanden, enthält **SwipeKlar-Buildprotokoll** das Xcode-Buildprotokoll. Ein erfolgreicher Cloud-Build prüft das Kompilieren, aber noch nicht die Bedienung auf deinem iPhone.

Der Build erzeugt eine **unsignierte** IPA. Sideloadly übernimmt die persönliche Signierung und Installation im nächsten Schritt. Ein direkter Download der IPA auf dem iPhone installiert die App noch nicht.

## 5. Sideloadly unter Windows einrichten

1. **Sideloadly** von der offiziellen Seite <https://sideloadly.io/> herunterladen und installieren. Für die meisten Windows-PCs passt die 64-Bit-Version.
2. Die dort verlinkten **Windows-Desktopversionen von iTunes und iCloud** installieren. Der Sideloadly-Anbieter verlangt dafür die Web-Installer und weist auf Konflikte mit den Microsoft-Store-Versionen hin. Falls diese bereits installiert sind, den Wechsel entsprechend seiner Hinweise durchführen.
3. Das iPhone entsperren und mit einem USB-Datenkabel verbinden. **Diesem Computer vertrauen** auf dem iPhone bestätigen. Falls der PC neu gestartet werden muss, danach das iPhone erneut verbinden.
4. Sideloadly öffnen und dein iPhone im Gerätefeld auswählen.
5. **SwipeKlar.ipa** aus Schritt 4 in Sideloadly ziehen.
6. Deine Apple-ID eingeben und **Start** anklicken. Die nötige Anmeldung samt eventuell angefordertem Bestätigungscode in Sideloadly durchführen.

## 6. App auf dem iPhone starten

1. Falls iOS ein nicht vertrauenswürdiges Entwicklerprofil meldet: **Einstellungen → Allgemein → VPN und Geräteverwaltung**, dein Entwicklerprofil auswählen und ihm vertrauen.
2. Falls erforderlich: **Einstellungen → Datenschutz & Sicherheit → Entwicklermodus** aktivieren, das iPhone neu starten und bestätigen. Der Eintrag kann erst nach dem ersten Installationsversuch erscheinen.
3. **SwipeKlar** öffnen, einen der drei Modi wählen und den Fotozugriff erlauben.

Prüfe zuerst mit einigen entbehrlichen Testfotos das Behalten, Vormerken, Rückgängig, Abwählen in der Übersicht und Abbrechen der iOS-Löschbestätigung. Eine bestätigte Löschung wird bei iCloud-Fotos mit anderen Geräten synchronisiert.

## 7. Alle sieben Tage erneuern

Mit einer kostenlosen Apple-ID läuft die Signatur nach sieben Tagen ab. Sideloadly bietet **Auto Refresh** an. Dafür müssen der PC und der Sideloadly-Hintergrunddienst laufen und das iPhone per USB oder korrekt eingerichtetem WLAN erreichbar sein. WLAN-Erkennung wird zuvor in iTunes über **Mit diesem iPhone über WLAN synchronisieren** eingerichtet.

Alternativ die gespeicherte IPA erneut über Sideloadly installieren. Verwende dieselbe Apple-ID und dieselbe Bundle-ID und installiere über die vorhandene App, damit die lokal gespeicherten Entscheidungen erhalten bleiben. Ein erneuter GitHub-Build ist zur bloßen Erneuerung nicht nötig. Nach Ablauf der GitHub-Aufbewahrungsfrist kannst du bei Bedarf einen neuen Build starten.

## Quellen und Prüfstand

- [Sideloadly – Downloads und Windows-Voraussetzungen](https://sideloadly.io/)
- [Sideloadly-FAQ – Sieben-Tage-Frist, Einrichtung und Auto Refresh](https://sideloadly.io/faq.html)
- [GitHub – kostenlose Standard-Buildrechner für öffentliche Projekte](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)
- [GitHub – Workflow manuell starten](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow)

Die Build-Anweisung und das Paket wurden hier vorbereitet; der Cloud-Build wurde noch nicht auf deinem GitHub-Konto gestartet. Diese Umgebung verfügt selbst über kein iOS-SDK. Es wurde noch keine echte IPA erzeugt oder auf einem iPhone getestet. Die Prüfergebnisse stehen in `VALIDIERUNG.md` im Quellcode-Paket.
